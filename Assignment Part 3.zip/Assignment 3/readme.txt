TOP LEFT
Map - Press M to open a full view map of current stage and again to remove it. Can still perform actions with map open. Didn't use Tab because it came with some unexpected problems within the browser. 
	Added in a few extra details missed from Part One to make things more clear. 
	Black = unvisited areas (fog of war) Applies to all rooms not entered
	Orange = visited areas (will show items dropped and outline of area)
	Green = Starting Area
	Purple = Shop
	Red = Boss Room 

Time - Automatically applies, no key press required. 

Gold - Press G to generate gold. Has a random chance to generate 10 or 100 which is how the game would function. 

TOP RIGHT 
Hearts - Press Arrow Key Up and Down to remove health. Look what happens when one half heart container remains. 

BOTTOM RIGHT
Weapons - Press 1, 2 or 3 to change between three weapons. 

Pistol - Left Click to shoot.

Machine Gun - Hold Left Click to Shoot.

Reload - Press R to reload. Pistol and Machine Gun have different reload times.  (Should implement bar and character animation)

BOTTOM LEFT - Press Left Arrow Key and Right Arrow Key to navigate items. Hover the item to see description. 
Press E to activate the item, but lose it in the process. 
	
	